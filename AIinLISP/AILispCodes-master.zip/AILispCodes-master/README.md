# AILispCodes
This repo contains working lisp codes done for basic AI experiments
